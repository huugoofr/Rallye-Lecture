<?php

    echo form_open(base_url('livre/chercher'));
    
    echo form_label('Titre','titre');
    echo form_input('titre',set_value('titre'));
    