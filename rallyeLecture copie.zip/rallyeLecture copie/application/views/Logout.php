<?php echo validation_errors(); ?>
<?php echo form_open('Logout/endSession'); ?>
<button type="submit">Logout</button>
<?php echo form_close(); ?>