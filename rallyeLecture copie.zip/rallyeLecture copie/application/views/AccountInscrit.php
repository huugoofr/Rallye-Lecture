Votre procédure d'inscription est terminée<br>
Vous pouvez maintenant vous connecter : <a href="<?
php echo base_url('Login/Index'); ?>">Login</a> 