<?php echo validation_errors(); ?>
<?php echo form_open('Account/create'); ?>
<br>
<br>
<br>
<?php
 $valeur = array("nom","prenom","login","password","passwordConfirmation");
 $libelles = array("Nom","Prénom","Mail","Mot de passe","Confirmez votre mot de passe");
 for ($i = 0; $i < 5; $i++){
     ?>
    <label><?php echo $libelles[$i]." :" ?></label>
    <input type="text" name=<?php echo $valeur[$i] ?> id=<?php echo $valeur[$i] ?>/><br/>
    <?php
 }
echo $this->aauth->generate_recaptcha_field();
?>
    <button type="submit">Créez votre compte</button>
    <?php echo form_close(); ?>

