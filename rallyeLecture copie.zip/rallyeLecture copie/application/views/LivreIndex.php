<!-- navigation -->
<div class="navigation">
    <a href="<?php echo base_url(); ?>">Home</a>
    <a href="<?php echo base_url('livre/add');?>">Ajouter</a> 
    <input type="text" class="searchBox" id="searchBox"> </input>
    <input type="submit" value="Search" class="btnInput" id="btnInput"> </input>
</div>
<table>
    <tr>
        <td>#</td>
        <td>titre</td>
        <td>Auteur</td>
        <td>couverture</td>
        <td>id editeur</td>
        <td>id quizz</td>
        <td>image</td>
        <td>Actions</td>
    </tr>
    
    
    <?php $count = 0;
        foreach ($livres as $l): 
            if ($count%2==0) 
                {
                ?> <tr  bgcolor="#F01111"><?php }
            else 
                {?> <tr bgcolor="#2E43FE"> <?php } ?>
            <td><?php echo $l['id']; ?></td>
            <td><?php echo $l['titre']; ?></td>
            <td><?php echo $l['nom']; ?></td>
            <td><?php echo $l['couverture']; ?></td>
            <td><?php echo $l['idEditeur']; ?></td>
            <td><?php echo $l['idQuizz']; ?></td>
            <td><img src="<?php echo base_url('img/'.$l['couverture']) ?>" alt="<?php echo $l['titre']; ?>" height="50" width="50"> </td>
            <td>
                <a href="<?php echo site_url('livre/edit/'.$l['id']); ?>">Edit</a> | 
                <a href="<?php echo site_url('livre/remove/'.$l['id']); ?>">Delete</a>
            </td>
        </tr>
    <?php $count=$count+1;
        endforeach; ?>
</table>
