    <!-- navigation -->
    <div class="navigation">
        <a href="<?php echo base_url(); ?>">home</a>
    </div>
    <?php echo phpinfo();?>