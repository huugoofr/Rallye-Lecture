<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$config['protocol']='smtp';
$config['smtp_host']='ssl://smtp.gmail';
$config['smpt_port']='465';
$config['smtp_timeout']='7';
$config['smtp_user']='petitbonum.2018.sio.jjr.fr@gmail.com';
$config['smtp_pass']='siojjrsiojjr';
$config['charset']='utf-8';
$config['mailtype']='html';
$config['wordwrap']=TRUE;
$config['newline']="\r\n";

?>
